import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enseignant-add',
  templateUrl: './enseignant-add.component.html',
  styleUrls: ['./enseignant-add.component.css']
})
export class EnseignantAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}