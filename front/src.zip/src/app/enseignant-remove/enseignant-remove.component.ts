import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enseignant-remove',
  templateUrl: './enseignant-remove.component.html',
  styleUrls: ['./enseignant-remove.component.css']
})
export class EnseignantRemoveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
