import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-matiere-add',
  templateUrl: './matiere-add.component.html',
  styleUrls: ['./matiere-add.component.css']
})
export class MatiereAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
