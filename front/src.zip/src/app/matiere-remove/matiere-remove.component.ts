import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-matiere-remove',
  templateUrl: './matiere-remove.component.html',
  styleUrls: ['./matiere-remove.component.css']
})
export class MatiereRemoveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
