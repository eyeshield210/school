import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-matiere-edit',
  templateUrl: './matiere-edit.component.html',
  styleUrls: ['./matiere-edit.component.css']
})
export class MatiereEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
