import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enseignant-detail',
  templateUrl: './enseignant-detail.component.html',
  styleUrls: ['./enseignant-detail.component.css']
})
export class EnseignantDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
