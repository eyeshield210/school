import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enseignant-edit',
  templateUrl: './enseignant-edit.component.html',
  styleUrls: ['./enseignant-edit.component.css']
})
export class EnseignantEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
